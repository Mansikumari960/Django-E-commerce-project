# Mini Amazon Clone (Django)
Quick start:

```bash
python -m venv .venv
.\.venv\Scripts\activate  # Windows
pip install -r requirements.txt

python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open /admin to add Products. Visit / to browse. Use Dummy Razorpay page to simulate payment.
