document.addEventListener('click', (e) => {
  if(e.target.matches('[data-add]')){
    // Future AJAX add-to-cart
  }
});
