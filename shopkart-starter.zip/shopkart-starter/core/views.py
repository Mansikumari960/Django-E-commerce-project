from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.db.models import F
from .models import Product, CartItem, Order, OrderItem
from .forms import SignUpForm

def _get_session_key(request):
    if not request.session.session_key:
        request.session.create()
    return request.session.session_key

def home(request):
    products = Product.objects.order_by('-created_at')[:8]
    return render(request, 'core/home.html', {'products': products})

def product_list(request):
    products = Product.objects.all()
    return render(request, 'core/product_list.html', {'products': products})

def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    return render(request, 'core/product_detail.html', {'product': product})

@require_POST
def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    qty = int(request.POST.get('qty', 1))

    if request.user.is_authenticated:
        item, created = CartItem.objects.get_or_create(user=request.user, product=product)
        item.qty = F('qty') + qty if not created else qty
        item.save()
    else:
        session_key = _get_session_key(request)
        item, created = CartItem.objects.get_or_create(session_key=session_key, product=product)
        item.qty = F('qty') + qty if not created else qty
        item.save()

    messages.success(request, 'Added to cart!')
    return redirect('cart')

def cart_detail(request):
    if request.user.is_authenticated:
        items = CartItem.objects.filter(user=request.user).select_related('product')
    else:
        items = CartItem.objects.filter(session_key=_get_session_key(request)).select_related('product')
    total = sum([it.product.price * it.qty for it in items])
    return render(request, 'core/cart.html', {'items': items, 'total': total})

@require_POST
def update_cart(request, pk):
    qty = int(request.POST.get('qty', 1))
    item = get_object_or_404(CartItem, pk=pk)
    if qty <= 0:
        item.delete()
    else:
        item.qty = qty
        item.save()
    return redirect('cart')

@login_required
def checkout(request):
    items = CartItem.objects.filter(user=request.user).select_related('product')
    if not items:
        messages.error(request, 'Your cart is empty.')
        return redirect('product_list')
    total = sum([it.product.price * it.qty for it in items])
    return render(request, 'core/checkout.html', {'items': items, 'total': total})

@login_required
def create_order(request):
    items = CartItem.objects.filter(user=request.user).select_related('product')
    if not items:
        messages.error(request, 'No items to order.')
        return redirect('cart')

    order = Order.objects.create(user=request.user, total_amount=sum([it.product.price * it.qty for it in items]))

    for it in items:
        OrderItem.objects.create(order=order, product=it.product, price=it.product.price, qty=it.qty)
    items.delete()

    return render(request, 'core/dummy_payment.html', {'order': order})

@login_required
def payment_success(request):
    order_id = request.GET.get('order_id')
    order = get_object_or_404(Order, order_id=order_id)
    order.status = 'paid'
    order.save()
    messages.success(request, 'Payment successful!')
    return render(request, 'core/success.html', {'order': order})

@login_required
def payment_failure(request):
    order_id = request.GET.get('order_id')
    order = get_object_or_404(Order, order_id=order_id)
    order.status = 'failed'
    order.save()
    messages.error(request, 'Payment failed!')
    return render(request, 'core/failure.html', {'order': order})

def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('home')
    else:
        form = SignUpForm()
    return render(request, 'core/signup.html', {'form': form})
