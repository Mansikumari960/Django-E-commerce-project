from django.contrib import admin
from .models import Product, CartItem, Order, OrderItem

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug": ("title",)}
    list_display = ("title","price","stock","created_at")

admin.site.register(CartItem)
admin.site.register(Order)
admin.site.register(OrderItem)
